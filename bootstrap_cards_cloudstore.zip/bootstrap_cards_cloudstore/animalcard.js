//function called at start
$(function(){
	
	console.log("started");
	
	
	//either get the data locally  (in case you have no internet connection)
	//getDataLocal();
	//or read them from the server
	getDataCloud();
	
});

function getDataCloud()
{
	$.get("https://webtechlecture.appspot.com/cloudstore/listobjects?owner=futterapp",function(serverJSON){
		fillCards(serverJSON);
	});
}

function getDataLocal()
{
  var serverJSON=[{"jsonstring":{"imageurl":"ferkel.jpg","futter":"möhre",
 "text":"Das Ferkelchen haben wir besonders lieb. Es wälzt sich stets in Schlamm und Dreck, kommt aber jeden Tag um gekrault zu werden. Es mag Möhren sehr gerne.",
 "title":"Ferkeli","alter":"jung"},"key":"ferkel"},{"jsonstring":{"imageurl":"lama.jpg","futter":"mais",
 "text":"Lamas sind ganz besondere Tiere und toll anzuschauen nach dazu. Hilde schaut immer sehr aufmerksam zu, wenn wir ins Gehege kommen und ihr Mais bringen.",
 "title":"Hildchen","alter":"alt"},"key":"hilde"},{"jsonstring":{"imageurl":"karlchen.jpg","futter":"mais",
 "text":"Unser kleines Karlchen, immer für einen Schabernack zu haben. Mit seiner guten Laune hält er uns alle auf Trab. Er mag Mais am liebsten!",
 "title":"Karlus","alter":"jung"},"key":"karlchen"},{"jsonstring":{"imageurl":"elephant.jpg",
 "futter":"salat","text":"Lieschen ist schon sehr sehr lange bei uns. Sie grüßt jeden Morgen alle Pfleger und ist den ganzen Tag vergnügt auf den Beinen. Besonders gerne hat sie Salat.",
 "title":"Lisa-Dorothea","alter":"alt"},"key":"lieschen"},{"jsonstring":{"imageurl":"widder.jpg","futter":"salat",
 "text":"Tom der stattliche Widder gibt im Großgehege oft den Ton an. Obwohl er große Hörner hat, besitzt er ein sanftes Gemüt und klaut den andern Tieren den Salat!",
 "title":"Tommi","alter":"alt"},"key":"tom"}];
  fillCards(serverJSON);
}

var libraryCards=[];//#global variable
function fillCards(aServerJSON)
{	

	var col1=$("#animalcontent1");
	var col2=$("#animalcontent2");
	
	col1.empty();
	
	if (aServerJSON.length>0)
	{
		jQuery.each(aServerJSON,function(index,objectJSON){
			var cardJSON=objectJSON.jsonstring;
			var cardKey=objectJSON.key;
			console.log(cardKey+" "+cardJSON.title+" "+cardJSON.futter);
			
			var cardDiv=createCard("pics/"+cardJSON.imageurl,cardJSON.title,cardJSON.text);
			libraryCards[cardJSON.futter.toLowerCase()]=cardDiv;
			if (col2.children().length>col1.children().length)
			{
				col1.append(cardDiv);	
			}else
			{
				col2.append(cardDiv);	
			}	
		});
	
	}
}

//function called when dropdown button is selected
function dropdown(value)
{
	console.log(value);
	$("#dropdownMenuButton").text(value);
	var cardDiv=libraryCards[value.toLowerCase()];
	if (cardDiv != undefined)
	{
		cardDiv.addClass("bg-info");
	}
}


//function creates a card
function createCard(imageurl,title,text)
{	 
	var card=$("<div/>").addClass("card m-4").css("width","18rem;");	
	var cardImage=$("<img/>").addClass("card-img-top");
	cardImage.attr("src",imageurl);
		
	var cardBody=$("<div/>").addClass("card-body");	
	var cardTitle=$("<h5/>").addClass("card-title");
	cardTitle.append(title);
		
	var cardText=$("<p/>").addClass("card-text");
	cardText.append(text);
		
	cardBody.append(cardTitle);
	cardBody.append(cardText);
	
	card.append(cardImage);
	card.append(cardBody);
		
	return card;
}

